package com.dbs.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.project.model.ProjectInfo;
import com.dbs.project.service.ProjectService;

@RestController
public class ProjectController {

	@Autowired
	ProjectService projectService;
	@GetMapping("/home")
	public List<ProjectInfo> getDetails(@RequestBody ProjectInfo projectInfo) {
		return projectService.findAllDetails(projectInfo);
	}

	
	@GetMapping("/checkCId")
	public List<String> checkCustomerId(@RequestParam String custId) {
		return projectService.validCustomerId(custId);
	}
	
	@GetMapping("/checkOverdraft")
	public String checkForOverDraft(@RequestParam int balance, @RequestParam String custId) {
		return !projectService.ValidateOverDraft(balance, custId)?"There is overdraft. Cannot send money more than the available balance" : "Money sent successfully";
	}

}
